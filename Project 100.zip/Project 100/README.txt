PROJECT: 100  (Godot 4.3+ project, everything is generated in code)

1. Open Godot 4.3 or newer (4.4 / 4.5 also work), click Import, pick project.godot.
2. Press F5 to run.

Controls: WASD move, mouse look, left click shoot, Shift sprint, Space jump,
E read terminals, 1/2 switch weapon, Esc free the mouse, R restart after the ending.

Files
  main.gd    builds the level, lights, HUD, terminals, spawns enemies/pickups, game flow
  player.gd  first-person controller, shooting, health, overdrive (low HP = hit harder)
  enemy.gd   robots (ranged), creatures (melee) and the boss
  pickup.gd  health / ammo / shotgun / key
  sfx.gd     sound effects generated in code

Tuning: stats live in main.gd (_spawn_enemy), room sizes in `rooms`, story text in _decorate().
