extends Node3D
# PROJECT: 100 - builds the whole level, enemies, HUD and game flow in code.

const H := 4.0          # room height
const T := 0.4          # wall thickness
const DOOR_W := 3.0
const DOOR_H := 3.0
const START_POS := Vector3(0.0, 0.1, -3.0)
const LEVEL_NAMES := ["CONTAINMENT", "FOUNDRY", "BIO-LABS", "REACTOR", "ARCHIVE", "ECHO VAULT"]
const BOSS_NAMES := ["THE WARDEN", "FURNACE COLOSSUS", "THE GRAFT", "REACTOR SAINT", "THE ARCHIVIST", "THE HOLLOW CROWN"]

# [z_near, z_far, width]
var rooms := [
	[0.0, -12.0, 12.0],    # 0 medical chamber
	[-12.0, -28.0, 12.0],  # 1 maintenance wing
	[-28.0, -44.0, 14.0],  # 2 research lab
	[-44.0, -60.0, 12.0],  # 3 security wing (key)
	[-60.0, -90.0, 22.0],  # 4 core chamber (boss)
	[-90.0, -130.0, 24.0], # 5 foundry
	[-130.0, -170.0, 28.0], # 6 bio-labs
	[-170.0, -215.0, 32.0], # 7 reactor
	[-215.0, -260.0, 34.0], # 8 archive
	[-260.0, -305.0, 36.0], # 9 echo vault
]

var level_root: Node3D
var player
var boss
var door_body
var bosses: Array[Node3D] = []
var level_gates: Array[StaticBody3D] = []
var enemies_defeated := 0
var total_enemies := 0
var final_boss_defeated := false
var ending_pending := false
var sfx_node
var terminal_data := []

var started := false
var finished := false
var boss_intro := false
var bosses_defeated := 0
var current_sector := 0
var checkpoint_pos := START_POS
var deaths := 0
var msg_timer := 0.0
var near_terminal := -1
var reading := -1

# HUD
var hud: CanvasLayer
var lbl_hp: Label
var lbl_ammo: Label
var lbl_obj: Label
var lbl_prompt: Label
var lbl_msg: Label
var log_panel: Panel
var log_label: Label
var flash_rect: ColorRect
var overlay: ColorRect
var overlay_label: Label
var boss_bar: ProgressBar
var lbl_stage: Label

# ---------------------------------------------------------------- setup

func _ready():
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_setup_input()
	_setup_environment()
	if sfx_node == null:
		sfx_node = load("res://sfx.gd").new()
		add_child(sfx_node)
	_build_level()
	_spawn_player()
	_spawn_things()
	_build_hud()
	_show_title()

func _setup_input():
	_add_key("move_forward", KEY_W)
	_add_key("move_back", KEY_S)
	_add_key("move_left", KEY_A)
	_add_key("move_right", KEY_D)
	_add_key("jump", KEY_SPACE)
	_add_key("sprint", KEY_SHIFT)
	_add_key("interact", KEY_E)
	_add_key("weapon_1", KEY_1)
	_add_key("weapon_2", KEY_2)
	_add_key("weapon_3", KEY_3)
	_add_key("weapon_4", KEY_4)
	_add_key("reload", KEY_R)
	_add_key("restart", KEY_R)
	if not InputMap.has_action("shoot"):
		InputMap.add_action("shoot")
		var ev := InputEventMouseButton.new()
		ev.button_index = MOUSE_BUTTON_LEFT
		InputMap.action_add_event("shoot", ev)

func _add_key(action: String, key: Key):
	if InputMap.has_action(action):
		return
	InputMap.add_action(action)
	var ev := InputEventKey.new()
	ev.physical_keycode = key
	InputMap.action_add_event(action, ev)

func _setup_environment():
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.006, 0.009, 0.018)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.28, 0.36, 0.48)
	env.ambient_light_energy = 0.32
	env.fog_enabled = true
	env.fog_light_color = Color(0.025, 0.045, 0.075)
	env.fog_density = 0.012
	env.glow_enabled = true
	env.glow_intensity = 0.65
	env.glow_bloom = 0.12
	env.ssao_enabled = true
	env.ssao_radius = 1.5
	env.ssao_intensity = 1.25
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	env.reflected_light_source = Environment.REFLECTION_SOURCE_BG
	we.environment = env
	add_child(we)

# ---------------------------------------------------------------- level

func _mat(color: Color, emissive := false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.62 if not emissive else 0.38
	m.metallic = 0.42
	if emissive:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = 2.5
	return m

func _visual_box(pos: Vector3, size: Vector3, color: Color, emissive := false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(color, emissive)
	mi.position = pos
	level_root.add_child(mi)
	return mi

func _box(pos: Vector3, size: Vector3, color: Color, emissive := false) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = pos
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(color, emissive)
	body.add_child(mi)
	var col := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	col.shape = sh
	body.add_child(col)
	level_root.add_child(body)
	return body

func _build_level():
	level_root = Node3D.new()
	add_child(level_root)

	for i in rooms.size():
		_build_room(i)

	# dividers between rooms (width, doorway?)
	_wall_z(0.0, 12.0, false)
	_wall_z(-12.0, 12.0, true)
	_wall_z(-28.0, 14.0, true)
	_wall_z(-44.0, 14.0, true)
	_wall_z(-60.0, 22.0, true)
	_wall_z(-90.0, 22.0, true)
	_wall_z(-130.0, 24.0, true)
	_wall_z(-170.0, 28.0, true)
	_wall_z(-215.0, 32.0, true)
	_wall_z(-260.0, 34.0, true)
	_wall_z(-305.0, 36.0, false)

	# locked door to the core chamber
	door_body = _box(Vector3(0.0, DOOR_H * 0.5, -60.0), Vector3(DOOR_W, DOOR_H, T * 0.8), Color(0.9, 0.1, 0.1), true)
	level_gates.append(_box(Vector3(0.0, DOOR_H * 0.5, -90.0), Vector3(DOOR_W, DOOR_H, T * 0.8), Color(1.0, 0.22, 0.08), true))
	level_gates.append(_box(Vector3(0.0, DOOR_H * 0.5, -130.0), Vector3(DOOR_W, DOOR_H, T * 0.8), Color(0.1, 0.8, 1.0), true))
	level_gates.append(_box(Vector3(0.0, DOOR_H * 0.5, -170.0), Vector3(DOOR_W, DOOR_H, T * 0.8), Color(0.8, 0.12, 1.0), true))
	level_gates.append(_box(Vector3(0.0, DOOR_H * 0.5, -215.0), Vector3(DOOR_W, DOOR_H, T * 0.8), Color(0.95, 0.72, 0.18), true))
	level_gates.append(_box(Vector3(0.0, DOOR_H * 0.5, -260.0), Vector3(DOOR_W, DOOR_H, T * 0.8), Color(0.55, 0.18, 1.0), true))

	_add_lights(0, Color(0.5, 0.85, 1.0))
	_add_lights(1, Color(0.9, 0.9, 1.0))
	_add_lights(2, Color(0.5, 1.0, 0.7))
	_add_lights(3, Color(1.0, 0.25, 0.2))
	_add_lights(4, Color(0.7, 0.3, 1.0))
	_add_lights(5, Color(1.0, 0.36, 0.12))
	_add_lights(6, Color(0.22, 0.95, 0.55))
	_add_lights(7, Color(0.2, 0.55, 1.0))
	_add_lights(8, Color(0.9, 0.72, 0.32))
	_add_lights(9, Color(0.48, 0.2, 1.0))

	_decorate()

func _build_room(i: int):
	var r = rooms[i]
	var z0: float = r[0]
	var z1: float = r[1]
	var w: float = r[2]
	var length := absf(z1 - z0)
	var zc := (z0 + z1) * 0.5
	_box(Vector3(0.0, -T * 0.5, zc), Vector3(w + T * 2.0, T, length), Color(0.16, 0.17, 0.2))
	_box(Vector3(0.0, H + T * 0.5, zc), Vector3(w + T * 2.0, T, length), Color(0.1, 0.1, 0.12))
	var wall_col := Color(0.22, 0.24, 0.28)
	_box(Vector3(-w * 0.5 - T * 0.5, H * 0.5, zc), Vector3(T, H, length), wall_col)
	_box(Vector3(w * 0.5 + T * 0.5, H * 0.5, zc), Vector3(T, H, length), wall_col)
	var floor_line := Color(0.12, 0.25, 0.31)
	if i == 5:
		floor_line = Color(0.38, 0.16, 0.06)
	elif i == 6:
		floor_line = Color(0.08, 0.35, 0.2)
	elif i == 7:
		floor_line = Color(0.08, 0.2, 0.45)
	elif i == 8:
		floor_line = Color(0.38, 0.28, 0.08)
	elif i == 9:
		floor_line = Color(0.25, 0.08, 0.48)
	for seam in range(1, int(length / 4.0)):
		var seam_z := z0 - float(seam) * 4.0
		_visual_box(Vector3(0.0, 0.012, seam_z), Vector3(w, 0.018, 0.035), floor_line)
	for side in [-1.0, 1.0]:
		var wall_x: float = float(side) * (w * 0.5 - 0.035)
		_visual_box(Vector3(wall_x, H * 0.5, zc), Vector3(0.025, H - 0.35, length - 0.5), Color(0.12, 0.15, 0.2))
		_visual_box(Vector3(wall_x - side * 0.02, H * 0.5, zc), Vector3(0.025, 0.035, length - 0.7), Color(0.12, 0.3, 0.36), true)
		_visual_box(Vector3(wall_x - side * 0.1, 0.1, zc), Vector3(0.035, 0.08, length - 0.8), floor_line.lightened(0.28), true)
		_visual_box(Vector3(wall_x - side * 0.1, H - 0.12, zc), Vector3(0.035, 0.035, length - 0.8), floor_line.lightened(0.42), true)

func _wall_z(z: float, w: float, doorway: bool):
	var wall_col := Color(0.25, 0.27, 0.32)
	if not doorway:
		_box(Vector3(0.0, H * 0.5, z), Vector3(w + T * 2.0, H, T), wall_col)
		return
	var half := w * 0.5 + T
	var seg := half - DOOR_W * 0.5
	var cx := (half + DOOR_W * 0.5) * 0.5
	_box(Vector3(-cx, H * 0.5, z), Vector3(seg, H, T), wall_col)
	_box(Vector3(cx, H * 0.5, z), Vector3(seg, H, T), wall_col)
	_box(Vector3(0.0, DOOR_H + (H - DOOR_H) * 0.5, z), Vector3(DOOR_W, H - DOOR_H, T), wall_col)

func _add_lights(i: int, color: Color):
	var r = rooms[i]
	var z0: float = r[0]
	var z1: float = r[1]
	var length := absf(z1 - z0)
	var n := int(ceil(length / 10.0))
	for k in n:
		var lz := z0 - length * (float(k) + 0.5) / float(n)
		var l := OmniLight3D.new()
		l.position = Vector3(0.0, H - 0.6, lz)
		l.light_color = color
		l.omni_range = 14.0
		l.light_energy = 1.35
		l.shadow_enabled = k == 0
		l.shadow_blur = 2.0
		level_root.add_child(l)
		_visual_box(Vector3(0.0, H - 0.05, lz), Vector3(1.4, 0.1, 0.5), color, true)
		_visual_box(Vector3(0.0, H - 0.11, lz), Vector3(2.2, 0.025, 0.08), Color(0.16, 0.22, 0.28))

func _crate(x: float, z: float, s := 1.2):
	_box(Vector3(x, s * 0.5, z), Vector3(s, s, s), Color(0.3, 0.28, 0.25))

func _panel(x: float, y: float, z: float, size: Vector3, color: Color):
	_box(Vector3(x, y, z), size, color, true)

func _pillar(x: float, z: float):
	_box(Vector3(x, H * 0.5, z), Vector3(1.4, H, 1.4), Color(0.2, 0.22, 0.27))

func _decorate():
	# medical chamber: the pod you woke up in
	_box(Vector3(0.0, 0.4, -1.2), Vector3(1.4, 0.8, 2.0), Color(0.7, 0.85, 0.9))
	_box(Vector3(0.0, 0.85, -1.2), Vector3(1.0, 0.06, 1.6), Color(0.3, 0.9, 1.0), true)
	_panel(-5.65, 2.2, -3.0, Vector3(0.08, 1.0, 3.2), Color(0.12, 0.24, 0.28))
	_panel(5.65, 2.2, -3.0, Vector3(0.08, 1.0, 3.2), Color(0.12, 0.24, 0.28))
	# maintenance wing
	_crate(-3.0, -16.0)
	_crate(3.0, -22.0)
	_crate(-3.8, -26.4)
	_panel(-5.7, 1.9, -18.0, Vector3(0.06, 0.5, 5.0), Color(0.4, 0.25, 0.12))
	_panel(5.7, 1.9, -25.0, Vector3(0.06, 0.5, 3.0), Color(0.4, 0.25, 0.12))
	# research lab
	_pillar(-4.0, -33.0)
	_pillar(4.0, -33.0)
	_pillar(-4.0, -39.0)
	_pillar(4.0, -39.0)
	# security wing
	_crate(-3.0, -50.0)
	_crate(3.0, -50.0)
	_crate(0.0, -54.0, 1.6)
	_panel(-5.7, 2.0, -49.0, Vector3(0.06, 0.8, 4.0), Color(0.45, 0.12, 0.1))
	# core chamber
	_pillar(-5.0, -70.0)
	_pillar(5.0, -70.0)
	_pillar(-5.0, -80.0)
	_pillar(5.0, -80.0)
	_crate(0.0, -75.0, 1.4)
	_panel(-10.6, 2.2, -70.0, Vector3(0.06, 1.1, 4.0), Color(0.34, 0.12, 0.42))
	_panel(10.6, 2.2, -80.0, Vector3(0.06, 1.1, 4.0), Color(0.34, 0.12, 0.42))
	# foundry sector
	_crate(-7.0, -98.0, 1.7)
	_crate(7.0, -108.0, 1.7)
	_pillar(-9.0, -119.0)
	_pillar(9.0, -119.0)
	_panel(-11.6, 2.0, -101.0, Vector3(0.06, 0.9, 6.0), Color(1.0, 0.28, 0.06))
	_panel(11.6, 2.0, -115.0, Vector3(0.06, 0.9, 5.0), Color(1.0, 0.28, 0.06))
	# bio-lab sector
	_pillar(-9.0, -139.0)
	_pillar(9.0, -139.0)
	_crate(-7.0, -151.0, 1.5)
	_crate(7.0, -158.0, 1.5)
	_panel(-13.6, 2.0, -148.0, Vector3(0.06, 1.0, 5.0), Color(0.08, 0.72, 0.32))
	_panel(13.6, 2.0, -163.0, Vector3(0.06, 1.0, 5.0), Color(0.08, 0.72, 0.32))
	# reactor sector
	_pillar(-11.0, -181.0)
	_pillar(11.0, -181.0)
	_pillar(-11.0, -201.0)
	_pillar(11.0, -201.0)
	_crate(-6.0, -190.0, 1.8)
	_crate(6.0, -208.0, 1.8)
	_panel(-15.6, 2.2, -184.0, Vector3(0.06, 1.2, 6.0), Color(0.08, 0.35, 1.0))
	_panel(15.6, 2.2, -202.0, Vector3(0.06, 1.2, 6.0), Color(0.08, 0.35, 1.0))
	# archive sector
	_pillar(-12.0, -227.0)
	_pillar(12.0, -227.0)
	_crate(-8.0, -239.0, 1.6)
	_crate(8.0, -247.0, 1.6)
	_panel(-16.6, 2.1, -235.0, Vector3(0.06, 1.0, 7.0), Color(0.82, 0.6, 0.12))
	_panel(16.6, 2.1, -253.0, Vector3(0.06, 1.0, 6.0), Color(0.82, 0.6, 0.12))
	# echo vault
	_pillar(-13.0, -270.0)
	_pillar(13.0, -270.0)
	_pillar(-13.0, -291.0)
	_pillar(13.0, -291.0)
	_crate(-7.0, -280.0, 1.8)
	_crate(7.0, -298.0, 1.8)
	_panel(-17.6, 2.2, -278.0, Vector3(0.06, 1.2, 7.0), Color(0.42, 0.12, 0.95))
	_panel(17.6, 2.2, -296.0, Vector3(0.06, 1.2, 7.0), Color(0.42, 0.12, 0.95))

	_add_terminal(Vector3(4.5, 0.0, -9.0), "DIAGNOSTIC // BOOT",
		"SUBJECT P-100 - PRESERVATION CYCLE COMPLETE.\nELAPSED: 36,525 DAYS.\nCYBERNETIC INTEGRATION: 94%.\nMEMORY INDEX: CORRUPTED.\n\nFACILITY STATUS: COMPROMISED.\nSECURITY PROTOCOL: HOSTILE.\n\nFind the red access key. Leave this place.")
	_add_terminal(Vector3(-5.0, 0.0, -6.0), "PATIENT INTAKE // H. AALAND",
		"NAME: HERLING AALAND. AGE: 41.\nNEXT OF KIN: MARA AALAND (SPOUSE), LENA AALAND (DAUGHTER, 9).\n\nCONSENT FORM SIGNED 14 OCTOBER. SUBJECT requested that all memory copies be encrypted until the neural graft stabilizes.\n\nHandwritten note, not part of the medical record: \"If I come back wrong, let me remember them before I remember the work.\"")
	_add_terminal(Vector3(5.0, 0.0, -18.0), "LEAD RESEARCHER // PERSONAL LOG",
		"Trials 97, 98, 99: failed. The copies do not hold. They wake up screaming in a stranger's body.\n\nTrial 100 will work. It has to. The board wants results and I have stopped sleeping.\n\nI told Mara the work was about saving lives. That was true at first. The first grant was signed after Lena's diagnosis.")
	_add_terminal(Vector3(-5.0, 0.0, -24.0), "MAINTENANCE // NIGHT SHIFT",
		"SHIFT NOTE, TECHNICIAN N. IBARRA:\nThe air scrubbers have been pulling metallic dust from the core vents again. Facilities says it is harmless. It sticks to the inside of my mask and tastes like pennies.\n\nI heard Aaland in the intercom at 03:10. He was standing right beside me when it spoke.")
	_add_terminal(Vector3(-6.0, 0.0, -36.0), "INCIDENT REPORT // SECURITY",
		"Trial 100 began at 02:14. The transfer exceeded containment. The thing in the core began rewriting the staff.\n\nEvacuation failed. To stop the process, the lead researcher was placed into preservation. If he is ever woken, he is the only one who can end it.")
	_add_terminal(Vector3(5.5, 0.0, -32.0), "AUDIO TRANSCRIPT // DR. SHAH",
		"AALAND: The copy isn't a copy. It's a prediction. Every time I change the source, it changes with me.\n\nSHAH: Then shut it down.\n\nAALAND: I can hear Lena in there.\n\nSHAH: Your daughter is at home, Herling.\n\n[RECORDING ENDS. Security note: Dr. Shah never made it to the evacuation lift.]")
	_add_terminal(Vector3(5.0, 0.0, -48.0), "ARMORY // ISSUE RECORD",
		"Last issue before lockdown: one compact submachine gun, one prototype induction rifle, three trauma packs.\n\nThe induction rifle's field coils were designed to disrupt the core's replication lattice. Do not fire it near an active containment relay.\n\nAuthorization: H. Aaland.")
	_add_terminal(Vector3(5.0, 0.0, -56.0), "FINAL ENTRY",
		"His access key opens the core chamber. The experiment waits behind that door. It speaks in his voice now.\n\nDr. Herling Aaland, if you hear this: you built it. You can end it.\n\nP.S. The red key is with security. I kept one round in the chamber for myself. I could not decide which of us deserved it.")
	_add_terminal(Vector3(-9.0, 0.0, -68.0), "CONTAINMENT // BLACK BOX",
		"CORE EVENT TIMELINE:\n02:14:03 - neural lattice synchronized.\n02:14:09 - all monitors report two subjects.\n02:15:41 - staff begin repeating the same phrase: \"Let me out.\"\n02:19:00 - emergency power cut. Core remains active.\n\nThe backup system has been making fresh copies of the subject after every fatal neural event. Each copy inherits a little more of the prior one's memory.")
	_add_terminal(Vector3(9.0, 0.0, -86.0), "MARA // UNSENT MESSAGE",
		"El, I got the call from Shah. Lena is stable. They have a treatment that might work, but you need to come home and sign the forms.\n\nYou keep saying you can bring her back. She's not gone. Please stop trying to make a machine answer for her.\n\nI left this message on every channel. If you wake up, come home.\n\n[NO DELIVERY RECEIPT]")
	_add_terminal(Vector3(-9.0, 0.0, -97.0), "FOUNDRY // SHIFT REPORT",
		"The core's alloys are being fed into the furnace without a crew. The machines keep stamping the same serial number into every plate: P-100.\n\nSomeone has changed the production queue. It now reads: BUILD A BODY THAT CAN SURVIVE THE TRANSFER.")
	_add_terminal(Vector3(11.0, 0.0, -144.0), "BIO-LAB // SPECIMEN LOG",
		"Specimens are adapting to the neural signal. Their tissue grows toward the strongest electrical source, then hardens around it.\n\nDo not bring the induction rifle into the isolation tanks. The last pulse woke every sample at once.")
	_add_terminal(Vector3(-13.0, 0.0, -185.0), "REACTOR // FINAL OVERRIDE",
		"Containment is failing. Six guardian cores are linked to the reactor lock.\n\nOnly after all six guardians are destroyed will the final seal release. Cut the lattice. Do not let it speak with your daughter's voice.")
	_add_terminal(Vector3(-15.0, 0.0, -224.0), "ARCHIVE // MEMORY INDEX",
		"The guardian has been cataloguing every version of Herling Aaland. Some copies lived for seconds. Some lasted long enough to remember their family.\n\nThe index has labeled the next sequence THE HOLLOW CROWN. No biological match found.")
	_add_terminal(Vector3(15.0, 0.0, -267.0), "ECHO VAULT // LAST RECORD",
		"Emergency override accepted. The guardians are gone, but the lattice is still learning from them.\n\nHerling, if you can hear this: you are not a copy. You are the one who can choose to stop.")

func _add_terminal(pos: Vector3, title: String, text: String):
	_box(Vector3(pos.x, 0.55, pos.z), Vector3(0.8, 1.1, 0.8), Color(0.12, 0.14, 0.18))
	_box(Vector3(pos.x, 1.15, pos.z), Vector3(0.7, 0.08, 0.7), Color(0.2, 0.9, 1.0), true)
	var l := OmniLight3D.new()
	l.position = Vector3(pos.x, 1.6, pos.z)
	l.light_color = Color(0.2, 0.9, 1.0)
	l.omni_range = 5.0
	l.light_energy = 1.0
	level_root.add_child(l)
	terminal_data.append({"pos": Vector3(pos.x, 0.6, pos.z), "title": title, "text": text})

# ---------------------------------------------------------------- spawning

func _spawn_player():
	player = preload("res://player.gd").new()
	player.position = START_POS
	add_child(player)
	player.died.connect(_on_player_died)

func _spawn_enemy(kind: String, pos: Vector3):
	var e = preload("res://enemy.gd").new()
	match kind:
		"robot":
			e.hp = 3.0
			e.speed = 2.5
			e.damage = 2.0
			e.ranged = true
			e.body_color = Color(0.35, 0.4, 0.5)
		"creature":
			e.hp = 2.0
			e.speed = 5.5
			e.damage = 2.0
			e.scale_factor = 0.9
			e.aggro_range = 14.0
			e.body_color = Color(0.45, 0.15, 0.2)
		"boss":
			var boss_number: int = bosses.size()
			e.hp = 45.0 + float(boss_number) * 15.0
			e.speed = 2.2
			e.damage = 5.0
			e.ranged = true
			e.shots = 3 + boss_number
			e.is_boss = true
			e.scale_factor = 2.2
			e.aggro_range = 40.0
			match boss_number:
				0:
					e.body_color = Color(0.5, 0.1, 0.6)
				1:
					e.body_color = Color(0.72, 0.18, 0.12)
				2:
					e.body_color = Color(0.12, 0.48, 0.24)
				3:
					e.body_color = Color(0.12, 0.25, 0.72)
				4:
					e.body_color = Color(0.78, 0.58, 0.12)
				_:
					e.body_color = Color(0.32, 0.12, 0.72)
			bosses.append(e)
	e.position = pos
	level_root.add_child(e)

func _spawn_pickup(kind: String, pos: Vector3):
	var p = preload("res://pickup.gd").new()
	p.kind = kind
	p.position = pos
	level_root.add_child(p)

func _spawn_things():
	# enemies
	_spawn_enemy("creature", Vector3(-3.0, 0.05, -20.0))
	_spawn_enemy("creature", Vector3(3.0, 0.05, -24.0))
	_spawn_enemy("robot", Vector3(0.0, 0.05, -38.0))
	_spawn_enemy("creature", Vector3(-5.0, 0.05, -31.0))
	_spawn_enemy("creature", Vector3(5.0, 0.05, -42.0))
	_spawn_enemy("robot", Vector3(-4.0, 0.05, -52.0))
	_spawn_enemy("robot", Vector3(4.0, 0.05, -56.0))
	_spawn_enemy("boss", Vector3(0.0, 0.05, -82.0))
	# Sector 2: foundry
	_spawn_enemy("creature", Vector3(-7.0, 0.05, -101.0))
	_spawn_enemy("robot", Vector3(6.0, 0.05, -109.0))
	_spawn_enemy("creature", Vector3(-5.0, 0.05, -114.0))
	_spawn_enemy("boss", Vector3(0.0, 0.05, -121.0))
	# Sector 3: bio-labs
	_spawn_enemy("robot", Vector3(-8.0, 0.05, -139.0))
	_spawn_enemy("creature", Vector3(7.0, 0.05, -148.0))
	_spawn_enemy("creature", Vector3(-6.0, 0.05, -155.0))
	_spawn_enemy("boss", Vector3(0.0, 0.05, -161.0))
	# Sector 4: reactor
	_spawn_enemy("robot", Vector3(-10.0, 0.05, -181.0))
	_spawn_enemy("creature", Vector3(9.0, 0.05, -188.0))
	_spawn_enemy("robot", Vector3(-8.0, 0.05, -194.0))
	_spawn_enemy("creature", Vector3(7.0, 0.05, -198.0))
	_spawn_enemy("boss", Vector3(0.0, 0.05, -203.0))
	# Level 5: archive
	_spawn_enemy("robot", Vector3(-10.0, 0.05, -226.0))
	_spawn_enemy("creature", Vector3(9.0, 0.05, -235.0))
	_spawn_enemy("robot", Vector3(-8.0, 0.05, -243.0))
	_spawn_enemy("boss", Vector3(0.0, 0.05, -250.0))
	# Level 6: echo vault
	_spawn_enemy("creature", Vector3(-11.0, 0.05, -269.0))
	_spawn_enemy("robot", Vector3(10.0, 0.05, -277.0))
	_spawn_enemy("creature", Vector3(-9.0, 0.05, -285.0))
	_spawn_enemy("robot", Vector3(8.0, 0.05, -289.0))
	_spawn_enemy("boss", Vector3(0.0, 0.05, -294.0))
	boss = bosses[0]
	total_enemies = get_tree().get_nodes_in_group("enemies").size()
	# pickups
	_spawn_pickup("ammo", Vector3(-4.0, 1.0, -8.0))
	_spawn_pickup("health", Vector3(5.0, 1.0, -14.0))
	_spawn_pickup("shotgun", Vector3(-5.0, 1.0, -26.5))
	_spawn_pickup("ammo", Vector3(5.0, 1.0, -26.0))
	_spawn_pickup("smg", Vector3(0.0, 1.0, -29.0))
	_spawn_pickup("health", Vector3(-6.0, 1.0, -30.0))
	_spawn_pickup("ammo", Vector3(6.0, 1.0, -42.0))
	_spawn_pickup("health", Vector3(-5.0, 1.0, -46.0))
	_spawn_pickup("smg", Vector3(0.0, 1.0, -46.5))
	_spawn_pickup("ammo", Vector3(5.0, 1.0, -46.0))
	_spawn_pickup("key", Vector3(0.0, 1.0, -58.0))
	_spawn_pickup("health", Vector3(-9.0, 1.0, -63.0))
	_spawn_pickup("health", Vector3(9.0, 1.0, -63.0))
	_spawn_pickup("ammo", Vector3(-9.0, 1.0, -65.0))
	_spawn_pickup("pulse", Vector3(0.0, 1.0, -66.0))
	_spawn_pickup("ammo", Vector3(9.0, 1.0, -65.0))
	_spawn_pickup("ammo", Vector3(-8.0, 1.0, -96.0))
	_spawn_pickup("health", Vector3(8.0, 1.0, -100.0))
	_spawn_pickup("health", Vector3(-10.0, 1.0, -108.0))
	_spawn_pickup("ammo", Vector3(10.0, 1.0, -114.0))
	_spawn_pickup("ammo", Vector3(-11.0, 1.0, -136.0))
	_spawn_pickup("health", Vector3(11.0, 1.0, -143.0))
	_spawn_pickup("ammo", Vector3(-11.0, 1.0, -155.0))
	_spawn_pickup("health", Vector3(11.0, 1.0, -163.0))
	_spawn_pickup("health", Vector3(-14.0, 1.0, -179.0))
	_spawn_pickup("ammo", Vector3(14.0, 1.0, -186.0))
	_spawn_pickup("ammo", Vector3(-14.0, 1.0, -197.0))
	_spawn_pickup("health", Vector3(14.0, 1.0, -206.0))
	_spawn_pickup("ammo", Vector3(-15.0, 1.0, -224.0))
	_spawn_pickup("health", Vector3(15.0, 1.0, -233.0))
	_spawn_pickup("ammo", Vector3(-15.0, 1.0, -245.0))
	_spawn_pickup("health", Vector3(15.0, 1.0, -253.0))
	_spawn_pickup("health", Vector3(-16.0, 1.0, -269.0))
	_spawn_pickup("ammo", Vector3(16.0, 1.0, -278.0))
	_spawn_pickup("ammo", Vector3(-16.0, 1.0, -288.0))
	_spawn_pickup("health", Vector3(16.0, 1.0, -298.0))

# ---------------------------------------------------------------- HUD

func _label(text: String, a: Rect2, o: Rect2, size := 22, align := HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	# a = anchors (left, top, right, bottom) packed in a Rect2; o = offsets packed the same way
	var l := Label.new()
	l.text = text
	l.anchor_left = a.position.x
	l.anchor_top = a.position.y
	l.anchor_right = a.size.x
	l.anchor_bottom = a.size.y
	l.offset_left = o.position.x
	l.offset_top = o.position.y
	l.offset_right = o.size.x
	l.offset_bottom = o.size.y
	l.horizontal_alignment = align
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_constant_override("outline_size", 4)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	hud.add_child(l)
	return l

func _build_hud():
	hud = CanvasLayer.new()
	add_child(hud)

	flash_rect = ColorRect.new()
	flash_rect.color = Color(1.0, 0.0, 0.0, 0.0)
	flash_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(flash_rect)

	lbl_hp = _label("", Rect2(0, 1, 0, 1), Rect2(24, -80, 460, -24), 28)
	lbl_ammo = _label("", Rect2(1, 1, 1, 1), Rect2(-460, -80, -24, -24), 28, HORIZONTAL_ALIGNMENT_RIGHT)
	lbl_obj = _label("", Rect2(0, 0, 0, 0), Rect2(24, 66, 800, 112), 22)
	lbl_prompt = _label("", Rect2(0.5, 0.5, 0.5, 0.5), Rect2(-300, 60, 300, 100), 22, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_msg = _label("", Rect2(0.5, 0, 0.5, 0), Rect2(-450, 100, 450, 160), 24, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_msg.add_theme_color_override("font_color", Color(1.0, 0.9, 0.4))
	var crosshair = preload("res://reticle.gd").new()
	crosshair.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(crosshair)
	lbl_stage = _label("", Rect2(0.5, 0, 0.5, 0), Rect2(-500, 10, 500, 42), 20, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_stage.add_theme_color_override("font_color", Color(0.55, 0.92, 1.0))

	boss_bar = ProgressBar.new()
	boss_bar.anchor_left = 0.5
	boss_bar.anchor_right = 0.5
	boss_bar.offset_left = -250
	boss_bar.offset_right = 250
	boss_bar.offset_top = 46
	boss_bar.offset_bottom = 64
	boss_bar.max_value = 45.0
	boss_bar.value = 45.0
	boss_bar.show_percentage = false
	boss_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss_bar.visible = false
	var boss_bg := StyleBoxFlat.new()
	boss_bg.bg_color = Color(0.025, 0.035, 0.055, 0.92)
	boss_bg.border_color = Color(0.3, 0.14, 0.42)
	boss_bg.set_border_width_all(2)
	boss_bg.set_corner_radius_all(4)
	boss_bar.add_theme_stylebox_override("background", boss_bg)
	var boss_fill := StyleBoxFlat.new()
	boss_fill.bg_color = Color(0.72, 0.12, 0.88)
	boss_fill.set_corner_radius_all(3)
	boss_bar.add_theme_stylebox_override("fill", boss_fill)
	hud.add_child(boss_bar)

	log_panel = Panel.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.02, 0.06, 0.08, 0.93)
	sb.border_color = Color(0.2, 0.9, 1.0)
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(8)
	log_panel.add_theme_stylebox_override("panel", sb)
	log_panel.anchor_left = 0.5
	log_panel.anchor_right = 0.5
	log_panel.anchor_top = 0.5
	log_panel.anchor_bottom = 0.5
	log_panel.offset_left = -380
	log_panel.offset_right = 380
	log_panel.offset_top = -285
	log_panel.offset_bottom = 245
	log_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	log_panel.visible = false
	hud.add_child(log_panel)
	log_label = Label.new()
	log_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	log_label.offset_left = 24
	log_label.offset_top = 20
	log_label.offset_right = -24
	log_label.offset_bottom = -20
	log_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	log_label.add_theme_font_size_override("font_size", 20)
	log_label.add_theme_color_override("font_color", Color(0.6, 1.0, 1.0))
	log_label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.7))
	log_label.add_theme_constant_override("shadow_offset_x", 1)
	log_label.add_theme_constant_override("shadow_offset_y", 2)
	log_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	log_panel.add_child(log_label)

	overlay = ColorRect.new()
	overlay.color = Color(0.0, 0.0, 0.0, 0.88)
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(overlay)
	overlay_label = Label.new()
	overlay_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	overlay_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	overlay_label.add_theme_font_size_override("font_size", 26)
	overlay_label.add_theme_color_override("font_color", Color(0.78, 0.94, 1.0))
	overlay_label.add_theme_constant_override("outline_size", 5)
	overlay_label.add_theme_color_override("font_outline_color", Color(0.0, 0.08, 0.12, 0.95))
	overlay_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.add_child(overlay_label)

func _show_title():
	overlay.visible = true
	overlay_label.text = "PROJECT: 100\n\nBOUNCE BACK\n\nSIX LEVELS: CONTAINMENT / FOUNDRY / BIO-LABS / REACTOR / ARCHIVE / ECHO VAULT\n\nWASD move   |   Mouse look   |   Click fire   |   Hold RMB aim / iron sights\nSMG and Pulse scopes zoom while aiming   |   R reload\nShift sprint   |   Space jump   |   E read records\n1-4 switch weapons as found   |   Esc free mouse\n\nClick to begin"

# ---------------------------------------------------------------- flow

func _input(event):
	if not started:
		if (event is InputEventMouseButton and event.pressed) or (event is InputEventKey and event.pressed):
			_begin()
		return
	if finished:
		if event.is_action_pressed("restart"):
			get_tree().reload_current_scene()
		return
	if event.is_action_pressed("ui_cancel"):
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		else:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		return
	if event.is_action_pressed("interact") and near_terminal != -1:
		if reading == near_terminal:
			reading = -1
			log_panel.visible = false
		else:
			reading = near_terminal
			var d = terminal_data[reading]
			log_label.text = str(d["title"]) + "\n\n" + str(d["text"]) + "\n\n[E] Close"
			log_panel.visible = true
			sfx("pickup")

func _begin():
	started = true
	overlay.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if is_instance_valid(player):
		player.active = true
		player.cooldown = 0.4
	say("You wake up. You do not remember your name.", 5.0)

func _process(delta):
	if player == null or not is_instance_valid(player):
		return
	_update_hud(delta)
	if not started or finished:
		return
	_update_door()
	_update_terminals()
	var sector_for_position := 0
	if player.global_position.z < -62.0:
		sector_for_position = 1
	if player.global_position.z < -92.0:
		sector_for_position = 2
	if player.global_position.z < -132.0:
		sector_for_position = 3
	if player.global_position.z < -172.0:
		sector_for_position = 4
	if player.global_position.z < -217.0:
		sector_for_position = 5
	if player.global_position.z < -262.0:
		sector_for_position = 6
	if sector_for_position > current_sector:
		_enter_sector(sector_for_position)

func _enter_sector(sector: int):
	current_sector = sector
	boss_intro = true
	match sector:
		1:
			checkpoint_pos = Vector3(0.0, 0.1, -62.0)
		2:
			checkpoint_pos = Vector3(0.0, 0.1, -94.0)
		3:
			checkpoint_pos = Vector3(0.0, 0.1, -134.0)
		4:
			checkpoint_pos = Vector3(0.0, 0.1, -174.0)
		5:
			checkpoint_pos = Vector3(0.0, 0.1, -219.0)
		6:
			checkpoint_pos = Vector3(0.0, 0.1, -264.0)
	if sector > 1 and sector <= bosses.size():
		boss = bosses[sector - 1]
	if is_instance_valid(boss):
		boss_bar.max_value = boss.hp
		boss_bar.value = boss.hp
		boss_bar.visible = true
	var sector_messages := [
		"",
		"PROJECT: 100 - \"You came back, Herling. I kept her voice for you.\"",
		"LEVEL 2 // FOUNDRY. The furnace has built a guardian from your old armor.",
		"LEVEL 3 // BIO-LABS. The specimens are moving toward the signal.",
		"LEVEL 4 // REACTOR. End the lattice before it copies you again.",
		"LEVEL 5 // ARCHIVE. It has saved every memory it stole from you.",
		"LEVEL 6 // ECHO VAULT. This is the last copy. Make it count."
	]
	say(sector_messages[sector] + "\nBOSS: " + BOSS_NAMES[sector - 1], 5.0)

func _update_hud(delta):
	if player == null or not is_instance_valid(player):
		return
	lbl_hp.text = "HP %d" % int(player.hp)
	if player.overdrive():
		lbl_hp.text += "   OVERDRIVE"
	lbl_ammo.text = "%s   %02d / %02d" % [String(player.weapon).to_upper(), player.magazines[player.weapon], player.ammo[player.weapon]]
	var stage_index := mini(maxi(current_sector, 1) - 1, LEVEL_NAMES.size() - 1)
	var boss_status: String = BOSS_NAMES[stage_index]
	if bosses_defeated > stage_index:
		boss_status += " // DEFEATED"
	lbl_stage.text = "LEVEL %02d // %s   |   BOSS: %s" % [stage_index + 1, LEVEL_NAMES[stage_index], boss_status]
	lbl_obj.text = "OBJECTIVE: " + _objective()
	msg_timer -= delta
	if msg_timer <= 0.0:
		lbl_msg.text = ""
	var low_alpha := 0.12 if player.overdrive() else 0.0
	flash_rect.color.a = maxf(flash_rect.color.a - delta * 1.5, low_alpha)
	if boss_bar.visible and is_instance_valid(boss):
		boss_bar.value = boss.hp

func _objective() -> String:
	if final_boss_defeated:
		var remaining := maxi(total_enemies - enemies_defeated, 0)
		return "Eliminate remaining hostiles: %d" % remaining if remaining > 0 else "All hostiles eliminated."
	if boss_intro:
		return "Defeat the Level %02d guardian." % (bosses_defeated + 1)
	if not player.has_key:
		return "Find the red access key."
	if is_instance_valid(door_body):
		return "Unlock the sealed door to the core chamber."
	return "Enter the core chamber."

func _update_door():
	if not is_instance_valid(door_body):
		return
	var d: float = player.global_position.distance_to(door_body.global_position)
	if d < 3.5:
		if player.has_key:
			door_body.queue_free()
			door_body = null
			sfx("door")
			say("Access granted. Core chamber unlocked.")
		elif msg_timer <= 0.0:
			say("Locked. Red access key required.", 2.0)

func _update_terminals():
	var nearest := -1
	var best := 2.6
	for i in terminal_data.size():
		var d: float = player.global_position.distance_to(terminal_data[i]["pos"])
		if d < best:
			best = d
			nearest = i
	near_terminal = nearest
	if nearest == -1:
		lbl_prompt.text = ""
		log_panel.visible = false
		reading = -1
	elif reading == nearest:
		lbl_prompt.text = ""
	else:
		lbl_prompt.text = "[E] Read terminal"

# called by other scripts
func sfx(id: String):
	if is_instance_valid(sfx_node):
		sfx_node.play(id)

func say(text: String, dur := 4.0):
	if lbl_msg == null:
		return
	lbl_msg.text = text
	msg_timer = dur

func on_player_hurt():
	flash_rect.color.a = 0.35

func _on_player_died():
	deaths += 1
	flash_rect.color.a = 0.8
	say("SIGNAL LOST. Restoring from backup...", 2.5)
	await get_tree().create_timer(2.5).timeout
	if finished:
		return
	player.respawn(checkpoint_pos)
	var recovery_lines := [
		"Backup #%d restored. A little more of the night comes back." % deaths,
		"Backup #%d restored. Mara's message. Lena is alive." % deaths,
		"Backup #%d restored. The core copied your guilt, not your daughter." % deaths,
		"Backup #%d restored. This time, you know what you are walking toward." % deaths
	]
	say(recovery_lines[mini(deaths - 1, recovery_lines.size() - 1)], 5.0)

func on_enemy_killed(is_boss: bool):
	enemies_defeated = mini(enemies_defeated + 1, total_enemies)
	if not is_boss:
		if final_boss_defeated:
			_try_finish_game()
		return
	bosses_defeated += 1
	boss_bar.visible = false
	var gate_index := bosses_defeated - 1
	if gate_index < level_gates.size() and is_instance_valid(level_gates[gate_index]):
		level_gates[gate_index].queue_free()
		sfx("door")
	if bosses_defeated >= bosses.size():
		final_boss_defeated = true
		if enemies_defeated < total_enemies:
			say("Final guardian down. Eliminate remaining hostiles: %d." % (total_enemies - enemies_defeated), 4.0)
		_try_finish_game()
		return
	boss = bosses[bosses_defeated]
	boss_bar.max_value = boss.hp
	boss_bar.value = boss.hp
	boss_bar.visible = false
	say("Guardian neutralized. Sector seal released.", 3.0)

func _try_finish_game():
	if not final_boss_defeated or enemies_defeated < total_enemies or ending_pending or finished:
		return
	ending_pending = true
	say("All hostiles eliminated. The lattice is finally breaking...", 3.0)
	await get_tree().create_timer(2.0).timeout
	if not finished:
		_end_game()

func _end_game():
	finished = true
	player.active = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	log_panel.visible = false
	overlay.visible = true
	overlay_label.text = "THE LATTICE IS SILENT.\n\nYou were Dr. Herling Aaland.\nYou failed once. You came back.\n\nBOUNCE BACK\n\nDeaths: %d\n\nPress R to play again" % deaths
