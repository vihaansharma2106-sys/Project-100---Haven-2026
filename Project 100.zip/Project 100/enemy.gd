extends CharacterBody3D
# One script for robots, creatures and the boss. Main sets the stats before adding it.

var hp := 3.0
var speed := 3.0
var damage := 2.0
var ranged := false
var shots := 1
var is_boss := false
var body_color := Color(0.5, 0.5, 0.55)
var scale_factor := 1.0
var aggro_range := 20.0

var attack_cooldown := 0.0
var telegraph := 0.0
var aggro := false
var dying := false
var flash_t := 0.0
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var player
var eye: MeshInstance3D
var eye_light: OmniLight3D
var body_mat: StandardMaterial3D

func _ready():
	add_to_group("enemies")
	_build_body()
	player = get_tree().get_first_node_in_group("player")
	if body_mat:
		body_mat.albedo_color = body_color

func _build_body():
	var s := scale_factor
	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(0.9, 1.8, 0.9) * s
	col.shape = box
	col.position.y = 0.9 * s
	add_child(col)

	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.82, 0.95, 0.68) * s if ranged else Vector3(0.9, 1.8, 0.9) * s
	mi.mesh = bm
	body_mat = _enemy_material(body_color, 0.72, 0.36)
	mi.material_override = body_mat
	mi.position.y = 1.0 * s if ranged else 0.9 * s
	add_child(mi)

	if ranged:
		_build_robot_model(s)
	else:
		mi.visible = false
		body_mat.metallic = 0.08
		body_mat.roughness = 0.82
		var torso := CapsuleMesh.new()
		torso.radius = 0.42 * s
		torso.height = 1.35 * s
		_add_model_piece(torso, Vector3(0.0, 0.88 * s, 0.0), body_mat)
		_build_creature_model(s)

	eye = MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.12 * s
	sm.height = 0.24 * s
	eye.mesh = sm
	var em := StandardMaterial3D.new()
	var eye_color := Color(0.75, 0.08, 1.0) if is_boss else Color(1.0, 0.12, 0.04)
	em.albedo_color = eye_color
	em.emission_enabled = true
	em.emission = eye_color
	em.emission_energy_multiplier = 4.0
	eye.material_override = em
	eye.position = Vector3(0.0, (1.55 if ranged else 1.48) * s, -0.38 * s)
	add_child(eye)
	eye_light = OmniLight3D.new()
	eye_light.light_color = eye_color
	eye_light.omni_range = 3.5 * s
	eye_light.light_energy = 1.2
	eye_light.position = eye.position
	add_child(eye_light)

func _enemy_material(color: Color, metalness: float, roughness: float, emissive := false) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metalness
	material.roughness = roughness
	if emissive:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 2.5
	return material

func _add_model_piece(mesh: Mesh, pos: Vector3, material: Material, rotation := Vector3.ZERO) -> MeshInstance3D:
	var piece := MeshInstance3D.new()
	piece.mesh = mesh
	piece.position = pos
	piece.rotation = rotation
	piece.material_override = material
	add_child(piece)
	return piece

func _piece_box(size: Vector3, pos: Vector3, color: Color, metalness := 0.65, emissive := false) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	return _add_model_piece(mesh, pos, _enemy_material(color, metalness, 0.32, emissive))

func _piece_sphere(radius: float, pos: Vector3, color: Color, metalness := 0.35) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	return _add_model_piece(mesh, pos, _enemy_material(color, metalness, 0.5))

func _piece_capsule(radius: float, height: float, pos: Vector3, color: Color, rotation := Vector3.ZERO) -> MeshInstance3D:
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height
	return _add_model_piece(mesh, pos, _enemy_material(color, 0.08, 0.82), rotation)

func _piece_cylinder(radius: float, height: float, pos: Vector3, color: Color, rotation := Vector3.ZERO, emissive := false) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 12
	return _add_model_piece(mesh, pos, _enemy_material(color, 0.7, 0.28, emissive), rotation)

func _build_robot_model(s: float):
	var armor := Color(0.16, 0.22, 0.29) if not is_boss else Color(0.24, 0.09, 0.31)
	var edge := Color(0.34, 0.43, 0.52) if not is_boss else Color(0.5, 0.16, 0.6)
	var accent := Color(0.1, 0.8, 1.0) if not is_boss else Color(0.85, 0.12, 1.0)
	_piece_box(Vector3(0.64, 0.42, 0.58) * s, Vector3(0.0, 1.58 * s, 0.0), armor, 0.8)
	_piece_box(Vector3(0.68, 0.54, 0.12) * s, Vector3(0.0, 1.02 * s, -0.48 * s), edge, 0.85)
	_piece_box(Vector3(0.42, 0.055, 0.035) * s, Vector3(0.0, 1.03 * s, -0.555 * s), accent, 0.3, true)
	for side in [-1.0, 1.0]:
		_piece_box(Vector3(0.38, 0.34, 0.48) * s, Vector3(side * 0.57 * s, 1.28 * s, 0.0), edge, 0.85)
		_piece_box(Vector3(0.24, 0.52, 0.26) * s, Vector3(side * 0.61 * s, 0.82 * s, 0.0), armor, 0.75)
		_piece_box(Vector3(0.3, 0.18, 0.3) * s, Vector3(side * 0.24 * s, 0.19 * s, -0.06 * s), edge, 0.85)
		_piece_box(Vector3(0.3, 0.58, 0.34) * s, Vector3(side * 0.24 * s, 0.49 * s, 0.02 * s), armor, 0.75)
	_piece_box(Vector3(0.7, 0.1, 0.48) * s, Vector3(0.0, 1.82 * s, 0.0), edge, 0.82)
	if ranged:
		_piece_box(Vector3(0.22, 0.22, 0.5) * s, Vector3(0.7 * s, 0.88 * s, -0.32 * s), Color(0.055, 0.07, 0.09), 0.92)
		_piece_box(Vector3(0.09, 0.09, 0.36) * s, Vector3(0.7 * s, 0.92 * s, -0.72 * s), accent, 0.35, true)
		_piece_box(Vector3(0.17, 0.12, 0.24) * s, Vector3(0.7 * s, 0.69 * s, -0.22 * s), Color(0.08, 0.1, 0.12), 0.75)
		_piece_cylinder(0.09 * s, 0.1 * s, Vector3(0.7 * s, 0.92 * s, -0.9 * s), accent, Vector3(PI * 0.5, 0.0, 0.0), true)

func _build_creature_model(s: float):
	var shadow_flesh := Color(0.16, 0.035, 0.055)
	var bone := Color(0.42, 0.24, 0.23)
	for side in [-1.0, 1.0]:
		_piece_capsule(0.17 * s, 0.74 * s, Vector3(side * 0.5 * s, 0.88 * s, 0.0), body_color, Vector3(0.0, 0.0, -side * 0.55))
		_piece_sphere(0.17 * s, Vector3(side * 0.69 * s, 0.55 * s, -0.02 * s), shadow_flesh)
		_piece_capsule(0.2 * s, 0.72 * s, Vector3(side * 0.23 * s, 0.35 * s, 0.02 * s), shadow_flesh, Vector3(0.0, 0.0, side * 0.06))
		for claw in range(2):
			var cone := CylinderMesh.new()
			cone.top_radius = 0.0
			cone.bottom_radius = 0.065 * s
			cone.height = 0.26 * s
			cone.radial_segments = 8
			_add_model_piece(cone, Vector3(side * (0.65 + float(claw) * 0.09) * s, 0.35 * s, -0.18 * s), _enemy_material(bone, 0.12, 0.38), Vector3(-PI * 0.5, 0.0, 0.0))
	var head := SphereMesh.new()
	head.radius = 0.31 * s
	head.height = 0.5 * s
	_add_model_piece(head, Vector3(0.0, 1.53 * s, -0.12 * s), _enemy_material(body_color.darkened(0.28), 0.05, 0.78))
	for spine in range(3):
		var spike := CylinderMesh.new()
		spike.top_radius = 0.0
		spike.bottom_radius = 0.14 * s
		spike.height = 0.34 * s
		spike.radial_segments = 8
		_add_model_piece(spike, Vector3(0.0, (1.38 - float(spine) * 0.3) * s, 0.34 * s), _enemy_material(shadow_flesh, 0.05, 0.88), Vector3(-0.25, 0.0, 0.0))

func _physics_process(delta):
	if dying:
		return
	if player == null or not is_instance_valid(player):
		player = get_tree().get_first_node_in_group("player")
		if player == null:
			return

	attack_cooldown = maxf(attack_cooldown - delta, 0.0)
	if flash_t > 0.0:
		flash_t = maxf(flash_t - delta, 0.0)
		if flash_t <= 0.0 and body_mat:
			body_mat.albedo_color = body_color
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = minf(velocity.y, 0.0)

	var to_p: Vector3 = player.global_position - global_position
	var flat := Vector3(to_p.x, 0.0, to_p.z)
	var dist := flat.length()
	var valid_target: bool = player.has_method("hurt") and not player.dead and player.active

	if not aggro and dist < aggro_range and valid_target:
		aggro = true
	if not aggro or not valid_target:
		velocity.x = move_toward(velocity.x, 0.0, speed * 2.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, speed * 2.0 * delta)
		telegraph = 0.0
		eye.scale = Vector3.ONE
		if eye_light:
			eye_light.light_energy = 1.2
		move_and_slide()
		return

	if dist > 0.1:
		look_at(Vector3(player.global_position.x, global_position.y, player.global_position.z), Vector3.UP)

	var stop_dist := 1.4 * scale_factor
	if ranged:
		stop_dist = 9.0

	if dist > stop_dist and telegraph <= 0.0:
		var dir := flat.normalized()
		velocity.x = dir.x * speed
		velocity.z = dir.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed * 2.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, speed * 2.0 * delta)
	move_and_slide()

	if ranged:
		if telegraph > 0.0:
			telegraph = maxf(telegraph - delta, 0.0)
			if telegraph <= 0.0:
				eye.scale = Vector3.ONE
				_fire()
				attack_cooldown = 1.4 if is_boss else 1.8
		elif attack_cooldown <= 0.0 and dist < 24.0 and _has_los():
			telegraph = 0.55
			eye.scale = Vector3.ONE * 2.5
	else:
		if dist < 1.7 * scale_factor and attack_cooldown <= 0.0 and _has_los():
			player.hurt(damage)
			attack_cooldown = 0.9
	if eye_light:
		var charge := clampf(telegraph / 0.55, 0.0, 1.0)
		eye_light.light_energy = lerpf(1.2, 3.2, charge)

func _has_los() -> bool:
	if player == null or not is_instance_valid(player):
		return false
	var space := get_world_3d().direct_space_state
	var from := global_position + Vector3(0.0, 1.4 * scale_factor, 0.0)
	var to: Vector3 = player.global_position + Vector3(0.0, 1.2, 0.0)
	var q := PhysicsRayQueryParameters3D.create(from, to)
	q.exclude = [get_rid()]
	var hit := space.intersect_ray(q)
	return not hit.is_empty() and hit["collider"] == player

func _fire():
	var m = get_tree().current_scene
	if m and m.has_method("sfx"):
		m.sfx("enemy_shot")
	if player == null or not is_instance_valid(player):
		return
	var from := global_position + Vector3(0.0, 1.4 * scale_factor, 0.0)
	var to: Vector3 = player.global_position + Vector3(0.0, 1.2, 0.0)
	if not _has_los():
		return
	_tracer(from, to)
	var shot_hit := false
	for i in shots:
		if randf() < 0.75:
			shot_hit = true
			break
	if shot_hit and player.has_method("hurt"):
		player.hurt(damage)

func _tracer(from: Vector3, to: Vector3):
	var scene = get_tree().current_scene
	if scene == null:
		return
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.05, 0.05, from.distance_to(to))
	mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.2, 0.2)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.2, 0.2)
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = mat
	scene.add_child(mi)
	mi.global_position = (from + to) * 0.5
	mi.look_at(to, Vector3.UP)
	get_tree().create_timer(0.08).timeout.connect(mi.queue_free)

func take_damage(n: float):
	if dying:
		return
	aggro = true
	hp -= n
	if body_mat:
		body_mat.albedo_color = Color(1.0, 1.0, 1.0)
	flash_t = 0.06
	if hp <= 0.0:
		_begin_death()

func _begin_death():
	dying = true
	collision_layer = 0
	collision_mask = 0
	for child in get_children():
		if child is CollisionShape3D:
			child.set_deferred("disabled", true)
	velocity = Vector3.ZERO

	var m = get_tree().current_scene
	if m and m.has_method("on_enemy_killed"):
		m.on_enemy_killed(is_boss)

	_spawn_death_burst()
	if eye_light:
		eye_light.light_color = Color(1.0, 0.72, 0.22)
		eye_light.light_energy = 10.0
		var light_tween := create_tween()
		light_tween.tween_property(eye_light, "light_energy", 0.0, 0.6)
	if body_mat:
		var material_tween := create_tween()
		material_tween.tween_property(body_mat, "albedo_color", body_color.lightened(0.65), 0.1)
		material_tween.tween_property(body_mat, "albedo_color", body_color.darkened(0.55), 0.35)

	var death_tween := create_tween()
	death_tween.set_parallel(true)
	var tumble := rotation + Vector3(randf_range(-0.45, 0.45), randf_range(-1.1, 1.1), randf_range(-0.55, 0.55))
	death_tween.tween_property(self, "rotation", tumble, 0.28).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	death_tween.tween_property(self, "scale", Vector3.ONE * 0.025, 0.82).set_delay(0.18).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
	var sink_target := position - Vector3.UP * 0.55 * scale_factor
	death_tween.tween_property(self, "position", sink_target, 0.82).set_delay(0.18).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
	get_tree().create_timer(1.05).timeout.connect(queue_free)

func _spawn_death_burst():
	var scene := get_tree().current_scene
	if scene == null:
		return
	var particles := CPUParticles3D.new()
	particles.amount = 56 if is_boss else 24
	particles.lifetime = 0.9
	particles.one_shot = true
	particles.explosiveness = 1.0
	particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	particles.emission_sphere_radius = 0.24 * scale_factor
	particles.direction = Vector3.UP
	particles.spread = 180.0
	particles.gravity = Vector3(0.0, -5.0, 0.0)
	particles.initial_velocity_min = 1.8
	particles.initial_velocity_max = 4.2 * scale_factor
	particles.scale_amount_min = 0.035 * scale_factor
	particles.scale_amount_max = 0.075 * scale_factor
	var spark_mesh := SphereMesh.new()
	spark_mesh.radius = 0.04
	spark_mesh.height = 0.08
	particles.mesh = spark_mesh
	var spark_material := StandardMaterial3D.new()
	spark_material.albedo_color = body_color.lightened(0.45)
	spark_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	spark_material.emission_enabled = true
	spark_material.emission = body_color.lightened(0.55)
	spark_material.emission_energy_multiplier = 3.0
	particles.material_override = spark_material
	scene.add_child(particles)
	particles.global_position = global_position + Vector3.UP * 0.9 * scale_factor
	particles.emitting = true
	get_tree().create_timer(1.2).timeout.connect(particles.queue_free)
