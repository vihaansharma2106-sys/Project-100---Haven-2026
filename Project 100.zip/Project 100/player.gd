extends CharacterBody3D

signal died

const WALK_SPEED := 6.0
const SPRINT_SPEED := 9.0
const JUMP_VELOCITY := 5.5
const MOUSE_SENS := 0.0025
const WEAPON_SIZES := {
	"pistol": Vector3(0.12, 0.14, 0.5),
	"shotgun": Vector3(0.16, 0.17, 0.78),
	"smg": Vector3(0.14, 0.16, 0.62),
	"pulse": Vector3(0.18, 0.2, 0.72),
}

var max_hp := 100.0
var hp := 100.0
var has_key := false
var has_shotgun := false
var has_smg := false
var has_pulse := false
var ammo := {"pistol": 48, "shotgun": 0, "smg": 0, "pulse": 0}
var magazines := {"pistol": 12, "shotgun": 0, "smg": 0, "pulse": 0}
var magazine_sizes := {"pistol": 12, "shotgun": 6, "smg": 30, "pulse": 5}
var weapon := "pistol"
var cooldown := 0.0
var reload_timer := 0.0
var reload_duration := 0.0
var reload_weapon := ""
var reload_part: MeshInstance3D
var reload_part_rest_position := Vector3.ZERO
var active := false
var dead := false
var bob_t := 0.0
var aiming := false
var aim_blend := 0.0

var cam: Camera3D
var gun: MeshInstance3D
var weapon_parts: Array[MeshInstance3D] = []
var laser_beam: MeshInstance3D
var laser_dot: MeshInstance3D
var flash: OmniLight3D
var muzzle_flash: MeshInstance3D
var muzzle_flash_material: StandardMaterial3D
var muzzle_flash_timer := 0.0
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

func _ready():
	add_to_group("player")
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	col.shape = cap
	col.position.y = 0.9
	add_child(col)

	cam = Camera3D.new()
	cam.position.y = 1.6
	cam.current = true
	cam.fov = 75.0
	add_child(cam)

	gun = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = WEAPON_SIZES[weapon]
	gun.mesh = bm
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Color(0.15, 0.17, 0.2)
	gm.metallic = 0.8
	gm.roughness = 0.32
	gun.material_override = gm
	gun.position = Vector3(0.28, -0.25, -0.5)
	cam.add_child(gun)
	_update_weapon_details()

	flash = OmniLight3D.new()
	flash.light_color = Color(1.0, 0.8, 0.4)
	flash.omni_range = 6.0
	flash.light_energy = 0.0
	flash.position = Vector3(0.28, -0.2, -1.0)
	cam.add_child(flash)
	muzzle_flash = MeshInstance3D.new()
	var flash_mesh := CylinderMesh.new()
	flash_mesh.top_radius = 0.0
	flash_mesh.bottom_radius = 0.09
	flash_mesh.height = 0.3
	flash_mesh.radial_segments = 12
	muzzle_flash.mesh = flash_mesh
	muzzle_flash.rotation.x = -PI * 0.5
	muzzle_flash.position = Vector3(0.28, -0.2, -1.18)
	muzzle_flash.visible = false
	muzzle_flash_material = StandardMaterial3D.new()
	muzzle_flash_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	muzzle_flash_material.emission_enabled = true
	muzzle_flash_material.emission_energy_multiplier = 4.0
	muzzle_flash.material_override = muzzle_flash_material
	cam.add_child(muzzle_flash)

	laser_beam = MeshInstance3D.new()
	var beam_mesh := BoxMesh.new()
	beam_mesh.size = Vector3(0.008, 0.008, 1.0)
	laser_beam.mesh = beam_mesh
	var beam_material := StandardMaterial3D.new()
	beam_material.albedo_color = Color(1.0, 0.025, 0.015, 0.8)
	beam_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	beam_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	beam_material.emission_enabled = true
	beam_material.emission = Color(1.0, 0.02, 0.01)
	beam_material.emission_energy_multiplier = 2.0
	laser_beam.material_override = beam_material
	laser_beam.top_level = true
	laser_beam.visible = false
	cam.add_child(laser_beam)

	laser_dot = MeshInstance3D.new()
	var dot_mesh := SphereMesh.new()
	dot_mesh.radius = 0.025
	dot_mesh.height = 0.05
	dot_mesh.radial_segments = 8
	dot_mesh.rings = 4
	laser_dot.mesh = dot_mesh
	var dot_material := StandardMaterial3D.new()
	dot_material.albedo_color = Color(1.0, 0.025, 0.015)
	dot_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	dot_material.emission_enabled = true
	dot_material.emission = Color(1.0, 0.02, 0.01)
	dot_material.emission_energy_multiplier = 3.0
	laser_dot.material_override = dot_material
	laser_dot.top_level = true
	laser_dot.visible = false
	cam.add_child(laser_dot)

func overdrive() -> bool:
	return hp > 0.0 and hp < 35.0

func _unhandled_input(event):
	if not active or dead:
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT:
		aiming = event.pressed
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * MOUSE_SENS)
		cam.rotation.x = clampf(cam.rotation.x - event.relative.y * MOUSE_SENS, -1.45, 1.45)
	if event.is_action_pressed("weapon_1"):
		_equip("pistol")
	elif event.is_action_pressed("weapon_2") and has_shotgun:
		_equip("shotgun")
	elif event.is_action_pressed("weapon_3") and has_smg:
		_equip("smg")
	elif event.is_action_pressed("weapon_4") and has_pulse:
		_equip("pulse")

func _equip(kind: String):
	if not WEAPON_SIZES.has(kind):
		return
	weapon = kind
	var bm := BoxMesh.new()
	bm.size = WEAPON_SIZES[kind]
	gun.mesh = bm
	var material := gun.material_override as StandardMaterial3D
	if material == null:
		material = StandardMaterial3D.new()
		gun.material_override = material
	match kind:
		"shotgun":
			material.albedo_color = Color(0.28, 0.18, 0.12)
		"smg":
			material.albedo_color = Color(0.16, 0.2, 0.19)
		"pulse":
			material.albedo_color = Color(0.14, 0.22, 0.26)
		_:
			material.albedo_color = Color(0.15, 0.17, 0.2)
	material.metallic = 0.8
	material.roughness = 0.32
	_update_weapon_details()

func _update_weapon_details():
	for part in weapon_parts:
		gun.remove_child(part)
		part.queue_free()
	weapon_parts.clear()
	reload_part = null

	var dimensions: Vector3 = WEAPON_SIZES[weapon]
	var length: float = dimensions.z
	var accent := Color(0.15, 0.8, 1.0)
	var dark_metal := Color(0.045, 0.06, 0.075)
	match weapon:
		"shotgun":
			accent = Color(1.0, 0.35, 0.08)
		"smg":
			accent = Color(0.15, 1.0, 0.42)
		"pulse":
			accent = Color(0.1, 0.75, 1.0)

	var barrel_length := length * 0.72
	_weapon_cylinder(barrel_length, 0.045, Vector3(0.0, 0.0, -length * 0.5 - barrel_length * 0.42), dark_metal)
	_weapon_cylinder(0.075, 0.065, Vector3(0.0, 0.0, -length * 0.5 - barrel_length * 0.88), Color(0.12, 0.15, 0.18))
	_weapon_part(Vector3(dimensions.x * 0.72, 0.035, length * 0.78), Vector3(0.0, dimensions.y * 0.58, 0.0), Color(0.09, 0.12, 0.15))
	var sight_y := dimensions.y * 0.9
	var rear_sight_z := length * 0.3
	_weapon_part(Vector3(dimensions.x * 0.55, 0.025, 0.055), Vector3(0.0, sight_y, rear_sight_z), dark_metal)
	_weapon_part(Vector3(0.022, 0.075, 0.05), Vector3(-dimensions.x * 0.22, sight_y + 0.035, rear_sight_z), accent, true)
	_weapon_part(Vector3(0.022, 0.075, 0.05), Vector3(dimensions.x * 0.22, sight_y + 0.035, rear_sight_z), accent, true)
	_weapon_part(Vector3(0.035, 0.075, 0.05), Vector3(0.0, sight_y, -length * 0.31), accent, true)
	_weapon_part(Vector3(dimensions.x * 0.64, dimensions.y * 1.55, dimensions.z * 0.26), Vector3(0.0, -dimensions.y * 1.1, length * 0.12), dark_metal)
	_weapon_part(Vector3(0.018, 0.025, length * 0.42), Vector3(-dimensions.x * 0.52, dimensions.y * 0.18, -length * 0.05), accent, true)
	_weapon_part(Vector3(0.04, 0.035, 0.08), Vector3(-dimensions.x * 0.62, -dimensions.y * 0.52, -length * 0.38), dark_metal)
	_weapon_part(Vector3(0.018, 0.022, 0.035), Vector3(-dimensions.x * 0.62, -dimensions.y * 0.52, -length * 0.405), Color(1.0, 0.02, 0.01), true)

	match weapon:
		"pistol":
			reload_part = _weapon_part(Vector3(0.1, 0.12, 0.12), Vector3(0.0, -dimensions.y * 0.35, 0.04), Color(0.12, 0.15, 0.18))
			_weapon_part(Vector3(0.04, 0.035, 0.11), Vector3(0.0, -dimensions.y * 0.25, 0.06), Color(0.45, 0.48, 0.5))
		"shotgun":
			reload_part = _weapon_part(Vector3(dimensions.x * 0.8, 0.13, length * 0.34), Vector3(0.0, -0.12, -length * 0.24), Color(0.32, 0.18, 0.09))
			_weapon_part(Vector3(dimensions.x * 0.9, 0.14, 0.3), Vector3(0.0, -0.025, length * 0.52), Color(0.2, 0.12, 0.08))
			_weapon_cylinder(length * 0.72, 0.035, Vector3(0.0, -0.12, -length * 0.2), Color(0.12, 0.14, 0.16))
		"smg":
			reload_part = _weapon_part(Vector3(dimensions.x * 0.82, 0.24, 0.16), Vector3(0.0, -0.14, length * 0.05), Color(0.09, 0.13, 0.12))
			_weapon_part(Vector3(dimensions.x * 0.8, 0.13, 0.24), Vector3(0.0, 0.0, length * 0.58), Color(0.1, 0.13, 0.14))
			_weapon_cylinder(0.12, 0.09, Vector3(0.0, 0.11, 0.0), accent, true)
		"pulse":
			reload_part = _weapon_part(Vector3(dimensions.x * 0.48, dimensions.y * 0.48, length * 0.65), Vector3(0.0, 0.0, 0.0), Color(0.07, 0.16, 0.2), true)
			_weapon_cylinder(length * 0.6, 0.035, Vector3(-dimensions.x * 0.58, 0.0, -length * 0.1), accent, true)
			_weapon_cylinder(length * 0.6, 0.035, Vector3(dimensions.x * 0.58, 0.0, -length * 0.1), accent, true)
			_weapon_part(Vector3(0.15, 0.08, 0.16), Vector3(0.0, dimensions.y * 1.05, 0.0), Color(0.1, 0.18, 0.21))
	if weapon == "smg" or weapon == "pulse":
		var scope_y := dimensions.y * 1.8
		var scope_x := dimensions.x * 1.35
		_weapon_part(Vector3(0.045, dimensions.y * 0.75, 0.08), Vector3(scope_x, dimensions.y * 1.15, -length * 0.07), dark_metal)
		_weapon_cylinder(length * 0.38, 0.045, Vector3(scope_x, scope_y, -length * 0.07), dark_metal)
		_weapon_cylinder(0.035, 0.065, Vector3(scope_x, scope_y, length * 0.12), accent)
		_weapon_cylinder(0.035, 0.065, Vector3(scope_x, scope_y, -length * 0.26), dark_metal)
		_weapon_cylinder(0.018, 0.045, Vector3(scope_x, scope_y, -length * 0.28), accent, true)
	if reload_part:
		reload_part_rest_position = reload_part.position

func _weapon_part(size: Vector3, pos: Vector3, color: Color, emissive := false) -> MeshInstance3D:
	var part := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	part.mesh = mesh
	part.position = pos
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = 0.78 if not emissive else 0.35
	material.roughness = 0.28
	if emissive:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 1.7
	part.material_override = material
	gun.add_child(part)
	weapon_parts.append(part)
	return part

func _weapon_cylinder(height: float, radius: float, pos: Vector3, color: Color, emissive := false) -> MeshInstance3D:
	var part := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 12
	part.mesh = mesh
	part.position = pos
	part.rotation.x = PI * 0.5
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = 0.82 if not emissive else 0.3
	material.roughness = 0.25
	if emissive:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 2.0
	part.material_override = material
	gun.add_child(part)
	weapon_parts.append(part)
	return part

func _update_laser_sight():
	if not active or dead:
		laser_beam.visible = false
		laser_dot.visible = false
		return

	var ray_origin: Vector3 = cam.global_position
	var ray_direction: Vector3 = -cam.global_transform.basis.z
	var aim_end: Vector3 = ray_origin + ray_direction * 80.0
	var space := get_world_3d().direct_space_state
	var aim_query := PhysicsRayQueryParameters3D.create(ray_origin, aim_end)
	aim_query.exclude = [get_rid()]
	var aim_hit := space.intersect_ray(aim_query)
	if not aim_hit.is_empty():
		aim_end = aim_hit["position"]

	var dimensions: Vector3 = WEAPON_SIZES[weapon]
	var laser_origin: Vector3 = gun.to_global(Vector3(-dimensions.x * 0.62, -dimensions.y * 0.52, -dimensions.z * 0.72))
	var laser_query := PhysicsRayQueryParameters3D.create(laser_origin, aim_end)
	laser_query.exclude = [get_rid()]
	var laser_hit := space.intersect_ray(laser_query)
	var laser_end: Vector3 = aim_end
	if not laser_hit.is_empty():
		laser_end = laser_hit["position"]

	var beam_length := laser_origin.distance_to(laser_end)
	var beam_mesh := laser_beam.mesh as BoxMesh
	beam_mesh.size.z = maxf(beam_length, 0.01)
	laser_beam.global_position = (laser_origin + laser_end) * 0.5
	laser_beam.look_at(laser_end, Vector3.UP)
	laser_beam.visible = beam_length > 0.01
	laser_dot.visible = not laser_hit.is_empty()
	if laser_dot.visible:
		laser_dot.global_position = laser_end

func _physics_process(delta):
	cooldown = maxf(cooldown - delta, 0.0)
	flash.light_energy = maxf(flash.light_energy - delta * 40.0, 0.0)
	if muzzle_flash_timer > 0.0:
		muzzle_flash_timer = maxf(muzzle_flash_timer - delta, 0.0)
		if muzzle_flash_timer == 0.0:
			muzzle_flash.visible = false

	if reload_timer > 0.0:
		reload_timer = maxf(reload_timer - delta, 0.0)
		if reload_timer == 0.0 and reload_weapon != "":
			var needed: int = magazine_sizes[reload_weapon] - magazines[reload_weapon]
			var loaded: int = mini(needed, ammo[reload_weapon])
			magazines[reload_weapon] += loaded
			ammo[reload_weapon] -= loaded
			reload_weapon = ""

	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = minf(velocity.y, 0.0)

	if not active or dead:
		aiming = false
		aim_blend = move_toward(aim_blend, 0.0, delta * 8.0)
		cam.fov = lerpf(cam.fov, 75.0, clampf(delta * 8.0, 0.0, 1.0))
		gun.position = Vector3(0.28, -0.25, -0.5)
		gun.rotation = Vector3.ZERO
		laser_beam.visible = false
		laser_dot.visible = false
		if reload_part:
			reload_part.position = reload_part_rest_position
		velocity.x = move_toward(velocity.x, 0.0, WALK_SPEED * 2.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, WALK_SPEED * 2.0 * delta)
		move_and_slide()
		return

	if is_on_floor() and Input.is_action_just_pressed("jump"):
		velocity.y = JUMP_VELOCITY

	var input := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var dir := (transform.basis * Vector3(input.x, 0.0, input.y)).normalized()
	var speed := SPRINT_SPEED if Input.is_action_pressed("sprint") else WALK_SPEED
	if input.length() > 0.0:
		velocity.x = dir.x * speed
		velocity.z = dir.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed * 2.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, speed * 2.0 * delta)
	move_and_slide()

	bob_t += delta * Vector2(velocity.x, velocity.z).length()
	var reload_motion := 0.0
	if reload_timer > 0.0 and reload_duration > 0.0:
		var reload_progress := 1.0 - reload_timer / reload_duration
		reload_motion = sin(reload_progress * PI)
	var aim_target := 1.0 if aiming and reload_timer <= 0.0 else 0.0
	aim_blend = move_toward(aim_blend, aim_target, delta * 8.0)
	var idle_position := Vector3(
		0.28,
		-0.25 + sin(bob_t * 1.5) * 0.012 * (1.0 - aim_blend) - reload_motion * 0.2,
		-0.5 + reload_motion * 0.12
	)
	var dimensions: Vector3 = WEAPON_SIZES[weapon]
	var sight_drop := dimensions.y * 0.9 + 0.12
	if weapon == "pistol":
		sight_drop += 0.08
	var sight_position := Vector3(0.0, -sight_drop, -0.5)
	gun.position = idle_position.lerp(sight_position, aim_blend)
	gun.rotation.z = lerpf(-reload_motion * 0.42, 0.0, aim_blend)
	var aim_fov := 65.0
	if weapon == "smg" or weapon == "pulse":
		aim_fov = 40.0
	var target_fov := aim_fov if aim_blend > 0.0 else 75.0
	cam.fov = lerpf(cam.fov, target_fov, clampf(delta * 8.0, 0.0, 1.0))
	if reload_part:
		if weapon == "shotgun":
			reload_part.position = reload_part_rest_position + Vector3(0.0, 0.0, reload_motion * 0.16)
		else:
			reload_part.position = reload_part_rest_position + Vector3(0.0, -reload_motion * 0.15, 0.0)
	_update_laser_sight()

	if Input.is_action_just_pressed("reload"):
		_reload()
	if magazines[weapon] == 0 and ammo[weapon] > 0 and reload_timer <= 0.0:
		_reload()

	var firing := Input.is_action_just_pressed("shoot") if weapon == "pistol" or weapon == "pulse" else Input.is_action_pressed("shoot")
	if firing and cooldown <= 0.0 and reload_timer <= 0.0 and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		shoot()

func _reload():
	if reload_timer > 0.0 or magazines[weapon] >= magazine_sizes[weapon] or ammo[weapon] <= 0:
		return
	reload_weapon = weapon
	reload_duration = 0.85 if weapon == "pistol" else (1.25 if weapon == "shotgun" else 1.45)
	reload_timer = reload_duration

func shoot():
	if magazines[weapon] <= 0:
		cooldown = 0.3
		_sfx("empty")
		return
	magazines[weapon] -= 1
	var od := overdrive()
	var dmg := 2.0 if od else 1.0
	var pellets := 1
	var spread := 0.0
	var max_range := 80.0
	if weapon == "pistol":
		cooldown = 0.22 if od else 0.38
		flash.light_color = Color(1.0, 0.78, 0.48)
		_sfx("shoot")
	elif weapon == "shotgun":
		pellets = 7
		spread = 0.06
		cooldown = 0.6 if od else 0.95
		flash.light_color = Color(1.0, 0.48, 0.2)
		_sfx("shotgun")
	elif weapon == "smg":
		dmg = 0.65 if not od else 1.3
		spread = 0.018
		cooldown = 0.075 if od else 0.095
		flash.light_color = Color(0.7, 1.0, 0.72)
		_sfx("shoot")
	else:
		dmg = 5.0 if not od else 10.0
		max_range = 110.0
		cooldown = 0.72 if od else 0.95
		flash.light_color = Color(0.18, 0.8, 1.0)
		_sfx("pulse")
	flash.light_energy = 6.0
	muzzle_flash_material.albedo_color = flash.light_color
	muzzle_flash_material.emission = flash.light_color
	muzzle_flash.scale = Vector3.ONE * (1.7 if weapon == "shotgun" else (1.25 if weapon == "pulse" else 1.0))
	muzzle_flash.visible = true
	muzzle_flash_timer = 0.055

	var space := get_world_3d().direct_space_state
	var origin := cam.global_position
	for i in pellets:
		var dir := -cam.global_transform.basis.z
		if spread > 0.0:
			dir += cam.global_transform.basis.x * randf_range(-spread, spread)
			dir += cam.global_transform.basis.y * randf_range(-spread, spread)
			dir = dir.normalized()
		var q := PhysicsRayQueryParameters3D.create(origin, origin + dir * max_range)
		q.exclude = [get_rid()]
		var hit := space.intersect_ray(q)
		if hit.is_empty():
			continue
		var c = hit["collider"]
		if c != null and c.has_method("take_damage"):
			c.take_damage(dmg)
			_sfx("hit")
			if weapon == "pulse":
				var second_q := PhysicsRayQueryParameters3D.create(hit["position"] + dir * 0.15, origin + dir * max_range)
				second_q.exclude = [get_rid(), c.get_rid()]
				var second_hit := space.intersect_ray(second_q)
				if not second_hit.is_empty() and second_hit["collider"].has_method("take_damage"):
					second_hit["collider"].take_damage(dmg * 0.65)

func hurt(amount: float):
	if dead or not active:
		return
	hp -= amount
	_sfx("hurt")
	var m = _main()
	if m and m.has_method("on_player_hurt"):
		m.on_player_hurt()
	if hp <= 0.0:
		hp = 0.0
		dead = true
		died.emit()

func respawn(pos: Vector3):
	global_position = pos
	rotation = Vector3.ZERO
	cam.rotation = Vector3.ZERO
	velocity = Vector3.ZERO
	hp = max_hp
	dead = false

func pickup(kind: String) -> String:
	match kind:
		"health":
			if hp >= max_hp:
				return ""
			hp = minf(hp + 40.0, max_hp)
			return "Repair kit applied."
		"ammo":
			ammo["pistol"] += 18
			if has_shotgun:
				ammo["shotgun"] += 6
			if has_smg:
				ammo["smg"] += 45
			if has_pulse:
				ammo["pulse"] += 3
			return "Ammo acquired."
		"shotgun":
			if not has_shotgun:
				has_shotgun = true
				magazines["shotgun"] = 6
				ammo["shotgun"] += 18
			else:
				ammo["shotgun"] += 12
			_equip("shotgun")
			return "12-gauge pump shotgun recovered. Press 1 / 2 to switch weapons."
		"smg":
			if not has_smg:
				has_smg = true
				magazines["smg"] = 30
			ammo["smg"] += 60
			_equip("smg")
			return "Compact submachine gun recovered. Press 3 to switch weapons."
		"pulse":
			if not has_pulse:
				has_pulse = true
				magazines["pulse"] = 5
			ammo["pulse"] += 10
			_equip("pulse")
			return "Prototype induction rifle recovered. Press 4 to switch weapons."
		"key":
			has_key = true
			return "Red access key acquired."
	return ""

func _main():
	return get_tree().current_scene

func _sfx(id: String):
	var m = _main()
	if m and m.has_method("sfx"):
		m.sfx(id)
