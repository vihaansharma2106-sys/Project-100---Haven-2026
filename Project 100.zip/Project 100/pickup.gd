extends Area3D
# Main sets the pickup kind before adding it.

var kind := "ammo"
var t := randf() * 6.0
var mesh: MeshInstance3D
var ring: MeshInstance3D
var base_y := 0.0

func _ready():
	var col := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 1.0
	col.shape = sh
	add_child(col)

	var m: Mesh
	var color: Color
	match kind:
		"health":
			var b := BoxMesh.new()
			b.size = Vector3(0.46, 0.38, 0.38)
			m = b
			color = Color(0.78, 0.86, 0.72)
		"shotgun":
			var b := BoxMesh.new()
			b.size = Vector3(0.15, 0.15, 0.9)
			m = b
			color = Color(1.0, 0.55, 0.1)
		"smg":
			var b := BoxMesh.new()
			b.size = Vector3(0.18, 0.18, 0.62)
			m = b
			color = Color(0.95, 0.68, 0.2)
		"pulse":
			var b := BoxMesh.new()
			b.size = Vector3(0.2, 0.2, 0.76)
			m = b
			color = Color(0.2, 0.9, 1.0)
		"key":
			var s := SphereMesh.new()
			s.radius = 0.22
			s.height = 0.44
			m = s
			color = Color(1.0, 0.1, 0.1)
		_:
			var b := BoxMesh.new()
			b.size = Vector3(0.46, 0.28, 0.36)
			m = b
			color = Color(0.52, 0.62, 0.24)

	mesh = MeshInstance3D.new()
	mesh.mesh = m
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = 0.4
	mat.metallic = 0.25
	mat.roughness = 0.58
	mesh.material_override = mat
	base_y = mesh.position.y
	add_child(mesh)
	if kind == "ammo":
		_build_ammo_model()
	elif kind == "health":
		_build_medkit_model()

	ring = MeshInstance3D.new()
	var ring_mesh := TorusMesh.new()
	ring_mesh.inner_radius = 0.42
	ring_mesh.outer_radius = 0.48
	ring.mesh = ring_mesh
	ring.position.y = -0.72
	var ring_mat := StandardMaterial3D.new()
	ring_mat.albedo_color = color
	ring_mat.emission_enabled = true
	ring_mat.emission = color
	ring_mat.emission_energy_multiplier = 1.0
	ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	ring.material_override = ring_mat
	add_child(ring)

	var l := OmniLight3D.new()
	l.light_color = color
	l.omni_range = 4.5
	l.light_energy = 1.5
	add_child(l)

	body_entered.connect(_on_body_entered)

func _build_ammo_model():
	_detail_box(Vector3(0.42, 0.035, 0.32), Vector3(0.0, 0.155, 0.0), Color(0.25, 0.32, 0.14), 0.35)
	_detail_box(Vector3(0.14, 0.075, 0.02), Vector3(0.0, 0.0, -0.19), Color(0.72, 0.68, 0.43), 0.3)
	_detail_box(Vector3(0.035, 0.09, 0.025), Vector3(-0.15, 0.0, -0.19), Color(0.72, 0.68, 0.43), 0.3)
	for i in range(5):
		var x := (float(i) - 2.0) * 0.07
		var casing := CylinderMesh.new()
		casing.top_radius = 0.0
		casing.bottom_radius = 0.027
		casing.height = 0.065
		casing.radial_segments = 8
		_detail_mesh(casing, Vector3(x, 0.19, 0.0), Color(0.78, 0.48, 0.12), 0.78, 0.24)

func _build_medkit_model():
	var strap := Color(0.17, 0.24, 0.2)
	_detail_box(Vector3(0.055, 0.4, 0.4), Vector3(-0.16, 0.0, 0.0), strap, 0.25)
	_detail_box(Vector3(0.055, 0.4, 0.4), Vector3(0.16, 0.0, 0.0), strap, 0.25)
	_detail_box(Vector3(0.24, 0.09, 0.025), Vector3(0.0, 0.0, -0.205), Color(0.72, 0.08, 0.08), 0.05)
	_detail_box(Vector3(0.085, 0.25, 0.025), Vector3(0.0, 0.0, -0.208), Color(0.72, 0.08, 0.08), 0.05)
	_detail_box(Vector3(0.19, 0.045, 0.16), Vector3(0.0, 0.22, 0.0), Color(0.45, 0.52, 0.45), 0.35)
	_detail_box(Vector3(0.13, 0.05, 0.03), Vector3(0.0, -0.17, -0.215), Color(0.22, 0.32, 0.25), 0.45)

func _detail_box(size: Vector3, pos: Vector3, color: Color, metallic: float):
	var box := BoxMesh.new()
	box.size = size
	_detail_mesh(box, pos, color, metallic, 0.55)

func _detail_mesh(detail: Mesh, pos: Vector3, color: Color, metallic: float, roughness: float):
	var part := MeshInstance3D.new()
	part.mesh = detail
	part.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.metallic = metallic
	mat.roughness = roughness
	part.material_override = mat
	mesh.add_child(part)

func _process(delta):
	t += delta
	if mesh:
		mesh.position.y = base_y + sin(t * 2.0) * 0.1
		mesh.rotate_y(delta * 1.5)
	if ring:
		ring.rotate_y(-delta * 0.5)
		var halo_scale := 1.0 + sin(t * 2.4) * 0.08
		ring.scale = Vector3.ONE * halo_scale

func _on_body_entered(body):
	if not body.is_in_group("player"):
		return
	var msg: String = body.pickup(kind)
	if msg == "":
		return
	var m = get_tree().current_scene
	if m and m.has_method("sfx"):
		m.sfx("pickup")
	if m and m.has_method("say"):
		m.say(msg)
	queue_free()
