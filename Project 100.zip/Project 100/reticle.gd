extends Control

const RETICLE_COLOR := Color(0.12, 0.88, 1.0, 0.9)
const ACCENT_COLOR := Color(1.0, 0.42, 0.12, 0.9)

var tracked_player: Variant = null
var aim_level := 0.0
var spread := 0.0

func _ready():
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _process(delta):
	if tracked_player == null or not is_instance_valid(tracked_player):
		tracked_player = get_tree().get_first_node_in_group("player")
	if tracked_player == null:
		visible = false
		return

	visible = tracked_player.active and not tracked_player.dead
	if not visible:
		return

	aim_level = tracked_player.aim_blend
	var horizontal_speed: float = Vector2(tracked_player.velocity.x, tracked_player.velocity.z).length()
	var weapon_spread := 0.0
	match str(tracked_player.weapon):
		"shotgun":
			weapon_spread = 4.0
		"smg":
			weapon_spread = 2.0
	var target_spread := minf(horizontal_speed * 0.65 + weapon_spread, 12.0)
	target_spread *= 1.0 - aim_level * 0.8
	spread = lerpf(spread, target_spread, clampf(delta * 7.0, 0.0, 1.0))
	queue_redraw()

func _draw():
	var center := size * 0.5
	var gap := lerpf(11.0, 5.0, aim_level) + spread
	var radius := 23.0 + spread * 0.45
	var axes := [Vector2.RIGHT, Vector2.DOWN, Vector2.LEFT, Vector2.UP]

	for quadrant in range(4):
		var start_angle := float(quadrant) * PI * 0.5 + 0.2
		var end_angle := float(quadrant + 1) * PI * 0.5 - 0.2
		draw_arc(center, radius, start_angle, end_angle, 18, RETICLE_COLOR, 1.25, true)

	for i in range(axes.size()):
		var axis: Vector2 = axes[i]
		var perpendicular := Vector2(-axis.y, axis.x)
		draw_line(center + axis * gap, center + axis * (gap + 8.0), RETICLE_COLOR, 1.6, true)
		draw_line(center + axis * (gap + 12.0), center + axis * (radius - 2.0), RETICLE_COLOR, 1.0, true)
		draw_line(center + axis * (radius + 4.0) - perpendicular * 2.5, center + axis * (radius + 4.0) + perpendicular * 2.5, ACCENT_COLOR, 1.3, true)

	for tick in range(8):
		var angle := TAU * float(tick) / 8.0
		var direction := Vector2(cos(angle), sin(angle))
		var tick_length := 4.0 if tick % 2 == 0 else 2.5
		draw_line(center + direction * (radius + 8.0), center + direction * (radius + 8.0 + tick_length), RETICLE_COLOR, 1.0, true)

	var diamond := PackedVector2Array([
		center + Vector2(0.0, -4.0),
		center + Vector2(4.0, 0.0),
		center + Vector2(0.0, 4.0),
		center + Vector2(-4.0, 0.0),
		center + Vector2(0.0, -4.0),
	])
	draw_polyline(diamond, ACCENT_COLOR, 1.2, true)
	draw_circle(center, 1.5, Color(1.0, 1.0, 1.0, 0.98))
