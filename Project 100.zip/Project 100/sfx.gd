extends Node
# Generates simple sound effects in code so the game needs no audio files.

var streams := {}
var players: Array[AudioStreamPlayer] = []
var idx := 0

func _ready():
	streams["shoot"] = _noise(0.12, 9.0, 0.5)
	streams["shotgun"] = _noise(0.25, 6.0, 0.7)
	streams["pulse"] = _tone(0.16, 720.0, 110.0, 0.5, false)
	streams["enemy_shot"] = _noise(0.15, 7.0, 0.35)
	streams["hit"] = _tone(0.06, 520.0, 520.0, 0.3, true)
	streams["hurt"] = _tone(0.18, 160.0, 80.0, 0.5, true)
	streams["pickup"] = _tone(0.18, 440.0, 880.0, 0.3, false)
	streams["empty"] = _tone(0.05, 200.0, 200.0, 0.2, true)
	streams["door"] = _tone(0.4, 120.0, 60.0, 0.4, true)
	for i in 8:
		var p := AudioStreamPlayer.new()
		p.autoplay = false
		p.bus = "Master"
		add_child(p)
		players.append(p)

func play(id: String) -> void:
	if players.is_empty() or not streams.has(id):
		return
	var p: AudioStreamPlayer = players[idx]
	idx = (idx + 1) % players.size()
	if p.playing:
		p.stop()
	p.stream = streams[id]
	p.play()

func _make(samples: PackedFloat32Array) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = 22050
	w.stereo = false
	var data := PackedByteArray()
	data.resize(samples.size() * 2)
	for i in samples.size():
		data.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32767.0))
	w.data = data
	return w

func _noise(dur: float, decay: float, vol: float) -> AudioStreamWAV:
	var n := int(22050 * dur)
	var s := PackedFloat32Array()
	s.resize(n)
	for i in n:
		var t := float(i) / float(n)
		s[i] = (randf() * 2.0 - 1.0) * vol * exp(-decay * t)
	return _make(s)

func _tone(dur: float, f0: float, f1: float, vol: float, square: bool) -> AudioStreamWAV:
	var n := int(22050 * dur)
	var s := PackedFloat32Array()
	s.resize(n)
	var phase := 0.0
	for i in n:
		var t := float(i) / float(n)
		var f := lerpf(f0, f1, t)
		phase += f / 22050.0
		var v := sin(phase * TAU)
		if square:
			v = 1.0 if v > 0.0 else -1.0
		s[i] = v * vol * (1.0 - t)
	return _make(s)
